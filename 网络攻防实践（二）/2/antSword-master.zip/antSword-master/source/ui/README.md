## 中国蚁剑::UI框架库
> 用于在插件、扩展以及自身模块中调用。    

**本UI框架基于`dhtmlx`进行二次封装API**    
开发者可以采用原生框架API进行开发，也可以使用本UI框架进行开发。

原生API文档：[http://docs.dhtmlx.com/](http://docs.dhtmlx.com/)
