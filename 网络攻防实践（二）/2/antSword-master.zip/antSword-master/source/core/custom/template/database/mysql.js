/*
<T>XDB</T>
<X>
com.mysql.jdbc.Driver
jdbc:mysql://localhost/test?user=root&password=123456
</X>
*/

module.exports = require('./default');