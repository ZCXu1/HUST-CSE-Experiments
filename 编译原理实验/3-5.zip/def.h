#ifndef __DEF__
#define __DEF__
#include "stdarg.h" //在C/C++函数中使用可变参数。这样在调用相同的函数名 func 的时候，编译器会自动识别入参列表的格式，从而调用相对应的函数体
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include <typeinfo>
//#include "toy.tab.h"
#include <bits/stdc++.h>
#include "astnode.h"
#endif